const express = require ("express");
const router = express.Router();
const db = require ("../db/connection");

// CAMBIAR ESTADO 1 o 0

router.post("/cambiar", (req,res) => {
    const {idDispositivo, estado} = req.body;

    const sql = `
        UPDATE Dispositivo
        SET Estado = ?
        WHERE IDDispositivo = ?
    `;

    db.query(sql, [estado, idDispositivo], (err) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ ok: true, mensaje: "Estado actualizado correctamente" });
    });
});

// OBTENER ESTADO ACTUAL
router.get("/:id", (req, res) => {
    const id = req.params.id;

    const sql = `SELECT Estado FROM Dispositivo WHERE IDDispositivo = ?`;

    db.query(sql, [id], (err, rows) => {
        if (err) return res.status(500).json({ error: err });
        res.json(rows[0]);
    });
});

module.exports = router;