const express = require("express");
const router = express.Router();
const db = require("../db/connection");

router.post("/nueva", (req, res) => {
    const { idSensor, consumo } = req.body;

    const sql = `
    INSERT INTO Lectura (IDSensor, Consumo, Fecha)
    VALUES (?, ?, NOW());
  `;

  db.query(sql, [idSensor, consumo], (err) => {
    if (err) return res.status(500).json({ error: err});
    res.json({ ok: true, mensaje: "Lectura registrada owo"});
  });
});

module.exports = router;