const express = require("express");
const router = express.Router();
const db = require("../db/connection");

// Usa el día más reciente para presentaciones
router.get("/", (req, res) => {
  const query = `
    SELECT SUM(Consumo) AS TotalHoy
    FROM Lectura
    WHERE DATE(Fecha) = (
      SELECT MAX(DATE(Fecha)) FROM Lectura
    );
  `;

  db.query(query, (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result[0]);
  });
});

module.exports = router;
