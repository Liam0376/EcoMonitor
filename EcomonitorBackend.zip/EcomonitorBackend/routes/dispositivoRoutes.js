const express = require("express");
const router = express.Router();
const db = require("../db/connection");

router.get("/", (req, res) => {
  const query = `
    SELECT Dispositivo.Nombre AS Nombre,
           Lugar.Nombre AS Lugar,
           Producto.Modelo AS Modelo
    FROM Dispositivo
    JOIN Lugar ON Dispositivo.IDLugar = Lugar.IDLugar
    JOIN Producto ON Dispositivo.IDProducto = Producto.IDProducto;
  `;

  db.query(query, (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result);
  });
});

module.exports = router;

router.post("/toggle", (req, res) => {
    const { idDispositivo, nuevoEstado } = req.body;

    const sql = `
        UPDATE Dispositivo
        SET Estado = ?
        WHERE IDDispositivo = ?
    `;
    db.query(sql, [nuevoEstado, idDispositivo], (err) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ ok: true });
    });
});


