const express = require("express");
const router = express.Router();
const db = require("../db/connection");

// Últimos 7 días
router.get("/", (req, res) => {

  const query = `
    SELECT DATE(Fecha) AS Dia, SUM(Consumo) AS TotalDia
    FROM Lectura
    GROUP BY DATE(Fecha)
    ORDER BY Dia DESC
    LIMIT 7;
  `;

  db.query(query, (err, result) => {
    if (err) return res.status(500).json({ error: err });

    // Ordenar de L a D
    const ordenado = result.reverse();
    res.json(ordenado);
  });
});

module.exports = router;
