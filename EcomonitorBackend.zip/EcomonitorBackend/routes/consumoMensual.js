const express = require("express");
const router = express.Router();
const db = require("../db/connection");

// Consumo del mes más reciente existente en BD
router.get("/", (req, res) => {

  const query = `
    SELECT SUM(Consumo) AS TotalMes
    FROM Lectura
    WHERE MONTH(Fecha) = (
      SELECT MONTH(MAX(Fecha)) FROM Lectura
    )
    AND YEAR(Fecha) = (
      SELECT YEAR(MAX(Fecha)) FROM Lectura
    );
  `;

  db.query(query, (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result[0]);
  });
});

module.exports = router;
