const express = require("express");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

// Rutas
app.use("/api/consumo/hoy", require("./routes/consumoHoy"));
app.use("/api/consumo/semana", require("./routes/consumoSemana"));
app.use("/api/consumo/mensual", require("./routes/consumoMensual"));
app.use("/api/dispositivos", require("./routes/dispositivoRoutes"));
app.use("/api/lecturas", require("./routes/lecturasRoutes"));
app.use("/api/control", require("./routes/controlDispositivo"));

// Puerto
app.listen(3000, () => {
  console.log("Servidor backend corriendo en http://localhost:3000");
});
